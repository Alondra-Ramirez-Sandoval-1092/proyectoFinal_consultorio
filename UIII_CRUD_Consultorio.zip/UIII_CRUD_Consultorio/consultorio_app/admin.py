from django.contrib import admin
from .models import Consultorio
# Register your models here.

admin.site.register(Consultorio)