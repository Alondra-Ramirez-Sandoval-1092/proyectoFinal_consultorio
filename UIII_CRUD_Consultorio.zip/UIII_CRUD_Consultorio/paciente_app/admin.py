from django.contrib import admin
from .models import Paciente
# Register your models here.

admin.site.register(Paciente)